*******************************************************************************
** Copyright � 2008 Xilinx, Inc. 
** This design is confidential and proprietary of Xilinx, Inc. All Rights Reserved.
*******************************************************************************
**   ____  ____ 
**  /   /\/   / 
** /___/  \  /   Vendor: Xilinx 
** \   \   \/    Version: 1.1.1
**  \   \        Filename: readme.txt 
**  /   /        Date Last Modified: MAY 30, 2008
** /___/   /\    Date Created: OCT 28, 2008
** \   \  /  \ 
**  \___\/\___\ 
** 
**Purpose: HDL sourcecode  for MultiBoot with Virtex-5 FPGAs and Platform Flash XL
**Reference: XAPP1100.zip
**   
*******************************************************************************
**
**  Disclaimer: LIMITED WARRANTY AND DISCLAMER. These designs are
**              provided to you "as is." Xilinx and its licensors make and you
**              receive no warranties or conditions, express, implied,
**              statutory or otherwise, and Xilinx specifically disclaims any
**              implied warranties of merchantability, noninfringement, or
**              fitness for a particular purpose. Xilinx does not warrant that
**              the functions contained in these designs will meet your
**              requirements, or that the operation of these designs will be
**              uninterrupted or error free, or that defects in the Designs
**              will be corrected. Furthermore, Xilinx does not warrant or
**              make any representations regarding use or the results of the
**              use of the designs in terms of correctness, accuracy,
**              reliability, or otherwise.
**
**              LIMITATION OF LIABILITY. In no event will Xilinx or its
**              licensors be liable for any loss of data, lost profits, cost
**              or procurement of substitute goods or services, or for any
**              special, incidental, consequential, or indirect damages
**              arising from the use or operation of the designs or
**              accompanying documentation, however caused and on any theory
**              of liability. This limitation will apply even if Xilinx
**              has been advised of the possibility of such damage. This
**              limitation shall apply notwithstanding the failure of the
**              essential purpose of any limited remedies herein.
**
*******************************************************************************

This readme describes how to use the files that come with XAPP1100.

*******************************************************************************

** IMPORTANT NOTES **
1) This reference system was built using Xilinx ISE 10.1.03.

2) PFX_MultiBoot_Module contains the VHDL/Verilog source used for implementations of the referance design
   described in the application note.

*******************************************************************************

The xapp1100.zip archive includes the following set of design files:

Directory Stucture and description
======================================
-xapp1100
	-simulation  (The following files in this directory are provided for the simulation purposes)
	   -PFX_MultiBoot_Module
	   -TB_PFX_MultiBoot_MOdule
	-Verilog
	   -PFX_MultiBoot_MOdule (This Verilog include all the necessary design modules to demonstrate the refernece design)
	-VHDL
	   -PFX_MultiBoot_Module (This VHDL include all the necessary design modules to demonstrate the refernece design)






