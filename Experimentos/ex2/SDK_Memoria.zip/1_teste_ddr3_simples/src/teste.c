#include "teste.h"

#define VERBOSE

int main(void) {
    uint8_t ret;
    XGpio Gpio;
    volatile int Delay;
    init_stdout();
#ifdef VERBOSE
    print("\r\nBootloader\r\n");
    print("Starting...\r\n");
#endif

    XGpio_Initialize(&Gpio, XPAR_LEDS_8BITS_DEVICE_ID);
    XGpio_SetDataDirection(&Gpio, LED_CHANNEL, ~LED);
    XGpio_DiscreteClear(&Gpio, LED_CHANNEL, LED);

#ifdef VERBOSE
    print ("Loading data to ddr3 @");
    putnum(DDR3_BASEADDR);
    print ("\r\n");
#endif

    ret = to_ddr3();

#ifdef VERBOSE
	print ("Finished!\r\n");
	print ("Loading data to LEDs from DDR3 @");
	putnum(DDR3_BASEADDR);
	print ("...\r\n");
#endif
	U32Ptr ddr3 = (U32Ptr)(DDR3_BASEADDR+DDR3_OFFSET);
	uint8_t  i  = 0;
	u32 data;
	for(i = 0; i < 15; i++,ddr3++) {
		RD_WORD(ddr3, data);
		print("DDR3: ");
		putnum(data);
		print(" (@");
		putnum((u32)ddr3);
		print(")\r\n");
		XGpio_DiscreteSet(&Gpio, LED_CHANNEL, data);
		for (Delay = 0; Delay < LED_DELAY; Delay++);
	}
#ifdef VERBOSE
	print ("THE END!\r\n");
#endif

    return ret;
}

static uint8_t to_ddr3(){
	U32Ptr ddr3 = (U32Ptr)(DDR3_BASEADDR+DDR3_OFFSET);
	uint8_t i = 0;

	for(i = 0; i < 8; i++,ddr3++)
		WR_WORD(ddr3, 0x01<<i);
	for(i = 1; i < 8; i++,ddr3++)
		WR_WORD(ddr3, 0x80>>i);

	return XST_SUCCESS;
}
