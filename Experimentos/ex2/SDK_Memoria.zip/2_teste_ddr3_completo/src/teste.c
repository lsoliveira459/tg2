#include "teste.h"

#define VERBOSE

int main(void) {
    uint8_t ret;
    XGpio Gpio;
    volatile int Delay;
    init_stdout();
#ifdef VERBOSE
    print("\r\nBootloader\r\n");
    print("Starting...\r\n");
#endif

    XGpio_Initialize(&Gpio, XPAR_LEDS_8BITS_DEVICE_ID);
    XGpio_SetDataDirection(&Gpio, LED_CHANNEL, ~LED);
    XGpio_DiscreteClear(&Gpio, LED_CHANNEL, LED);

#ifdef VERBOSE
    print ("Loading data to ddr3 @");
    putnum(DDR3_BASEADDR);
    print ("...\r\n");
#endif

    ret = to_ddr3();

#ifdef VERBOSE
	print ("Finished!\r\n");
#endif
	U32Ptr ddr3 = (U32Ptr)(DDR3_BASEADDR+DDR3_OFFSET);
	uint32_t data;
	for(;(U32Ptr)(DDR3_BASEADDR+DDR3_OFFSET) <= ddr3 && ddr3 <= (U32Ptr)(DDR3_HIGHADDR); ddr3+=DDR3_INCREMENT) {
		RD_WORD(ddr3, data);
		print("DDR3 to LEDs: ");
		putnum(data);
		print(" (@");
		putnum((u32)ddr3);
		print(")\r\n");
		XGpio_DiscreteSet(&Gpio, LED_CHANNEL, data);
		for (Delay = 0; Delay < LED_DELAY; Delay++);
	}
#ifdef VERBOSE
	print ("THE END!\r\n");
#endif

    return ret;
}

static uint8_t to_ddr3(){
	U32Ptr ddr3 = (U32Ptr)(DDR3_BASEADDR+DDR3_OFFSET);
	uint8_t i = 0;
	for(; (U32Ptr)(DDR3_BASEADDR+DDR3_OFFSET) <= ddr3 && ddr3 <= (U32Ptr)(DDR3_HIGHADDR); ddr3+=DDR3_INCREMENT,i++) {
#ifdef VERBOSE
		if((u32)ddr3%0x01000000 == 0){
			print ("Writing to DDR3 @");
			putnum((u32)(ddr3));
			print ("...\r\n");
		}
#endif
		i = i%8;
		WR_WORD(ddr3, 0x01<<i);
	}

	return XST_SUCCESS;
}
