#include "teste.h"

#define VERBOSE

int main(void) {
    uint8_t ret;
    XGpio Gpio;
    volatile int Delay;
    init_stdout();
#ifdef VERBOSE
    print("\r\nBootloader\r\n");
    print("Starting...\r\n");
#endif

    XGpio_Initialize(&Gpio, XPAR_LEDS_8BITS_DEVICE_ID);
    XGpio_SetDataDirection(&Gpio, LED_CHANNEL, ~LED);
    XGpio_DiscreteClear(&Gpio, LED_CHANNEL, LED);

#ifdef VERBOSE
    print ("Loading data to flash @");
    putnum(FLASH_BASEADDR);
    print ("...\r\n");
#endif

    ret = to_flash();

#ifdef VERBOSE
	print ("Finished!\r\n");
#endif
	U32Ptr flash = (U32Ptr)(FLASH_BASEADDR+FLASH_OFFSET);
	uint32_t data;
	for(;(U32Ptr)(FLASH_BASEADDR+FLASH_OFFSET) <= flash && flash <= (U32Ptr)(FLASH_HIGHADDR); flash+=FLASH_INCREMENT) {
		RD_WORD(flash, data);
		print("FLASH to LEDs: ");
		putnum(data);
		print(" (@");
		putnum((u32)flash);
		print(")\r\n");
		XGpio_DiscreteSet(&Gpio, LED_CHANNEL, data);
		for (Delay = 0; Delay < LED_DELAY; Delay++);
	}
#ifdef VERBOSE
	print ("THE END!\r\n");
#endif

    return ret;
}

static uint8_t to_flash(){
	U32Ptr flash = (U32Ptr)(FLASH_BASEADDR+FLASH_OFFSET);
	uint8_t i = 0;
	for(; (U32Ptr)(FLASH_BASEADDR+FLASH_OFFSET) <= flash && flash <= (U32Ptr)(FLASH_HIGHADDR); flash+=FLASH_INCREMENT,i++) {
#ifdef VERBOSE
		if((u32)flash%0x00010000 == 0){
			print ("Writing to FLASH @");
			putnum((u32)(flash));
			print ("...\r\n");
		}
#endif
		i = i%8;
		WR_WORD(flash, 0x01<<i);
	}

	return XST_SUCCESS;
}
