#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "xparameters.h"
#include "xil_cache.h"
#include "xgpio.h"

#ifdef STDOUT_IS_16550
#include "xuartns550_l.h"
#endif

#ifdef PRE_2_00A_APPLICATION
#define XGpio_SetDataDirection(InstancePtr, DirectionMask) XGpio_SetDataDirection(InstancePtr, LED_CHANNEL, DirectionMask)
#define XGpio_DiscreteRead(InstancePtr) XGpio_DiscreteRead(InstancePtr, LED_CHANNEL)
#define XGpio_DiscreteWrite(InstancePtr, Mask) XGpio_DiscreteWrite(InstancePtr, LED_CHANNEL, Mask)
#define XGpio_DiscreteSet(InstancePtr, Mask) XGpio_DiscreteSet(InstancePtr, LED_CHANNEL, Mask)
#endif

typedef unsigned char   uint8_t;
typedef unsigned short  uint16_t;
typedef unsigned int    uint32_t;

typedef char   int8_t;
typedef short  int16_t;
typedef int    int32_t;

typedef volatile u32 *U32Ptr;

/* Defines */
#define CR 						13
#define FLASH_BASEADDR  		0x80000000
#define FLASH_HIGHADDR			0x87FFFFFF
#define FLASH_OFFSET			0x00004000
#define FLASH_INCREMENT			0x00000001

#define LED 0xFF
#define LED_CHANNEL 1
#define LED_DELAY 50000

#define WR_WORD(ADDR, DATA)	(*(U32Ptr)(ADDR) = (DATA))
#define RD_WORD(ADDR, DATA)	((DATA) = *(U32Ptr)(ADDR))

/* We don't use interrupts/exceptions.
   Dummy definitions to reduce code size on MicroBlaze */
#ifdef __MICROBLAZE__
void _interrupt_handler(){}
void _exception_handler(){}
void _hw_exception_handler(){}
#endif

void init_stdout() {
    /* if we have a uart 16550, then that needs to be initialized */
#ifdef STDOUT_IS_16550
    XUartNs550_SetBaud(STDOUT_BASEADDR, XPAR_XUARTNS550_CLOCK_HZ, 9600);
    XUartNs550_SetLineControlReg(STDOUT_BASEADDR, XUN_LCR_8_DATA_BITS);
#endif
}

/* Declarations */
static uint8_t 	to_flash();

#ifdef __cplusplus
extern "C" {
#endif

extern void outbyte(char c);

#ifdef __cplusplus
}
#endif
