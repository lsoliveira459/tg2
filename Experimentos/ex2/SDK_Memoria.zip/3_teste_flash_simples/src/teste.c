#include "teste.h"

#define VERBOSE

int main(void) {
    uint8_t ret;
    XGpio Gpio;
    volatile int Delay;
    init_stdout();
#ifdef VERBOSE
    print("\r\nBootloader\r\n");
    print("Starting...\r\n");
#endif

    XGpio_Initialize(&Gpio, XPAR_LEDS_8BITS_DEVICE_ID);
    XGpio_SetDataDirection(&Gpio, LED_CHANNEL, ~LED);
    XGpio_DiscreteClear(&Gpio, LED_CHANNEL, LED);

#ifdef VERBOSE
    print ("Loading data to flash @");
    putnum(FLASH_BASEADDR);
    print ("\r\n");
#endif

    ret = to_flash();

#ifdef VERBOSE
	print ("Finished!\r\n");
	print ("Loading data to LEDs from FLASH @");
	putnum(FLASH_BASEADDR);
	print ("...\r\n");
#endif
	U32Ptr flash = (U32Ptr)(FLASH_BASEADDR+FLASH_OFFSET);
	uint8_t  i  = 0;
	u32 data;
	for(i = 0; i < 15; i++,flash++) {
		RD_WORD(flash, data);
		print("FLASH: ");
		putnum(data);
		print(" (@");
		putnum((u32)flash);
		print(")\r\n");
		XGpio_DiscreteSet(&Gpio, LED_CHANNEL, data);
		for (Delay = 0; Delay < LED_DELAY; Delay++);
	}
#ifdef VERBOSE
	print ("THE END!\r\n");
#endif

    return ret;
}

static uint8_t to_flash(){
	U32Ptr flash = (U32Ptr)(FLASH_BASEADDR+FLASH_OFFSET);
	uint8_t i = 0;

	for(i = 0; i < 8; i++,flash++)
		WR_WORD(flash, 0x01<<i);
	for(i = 1; i < 8; i++,flash++)
		WR_WORD(flash, 0x80>>i);

	return XST_SUCCESS;
}
