#include "xparameters.h"    /* EDK generated parameters */
#include "xspi.h"           /* SPI device driver */
#include "xil_printf.h"
#include "string.h"

#define SPI_DEVICE_ID           XPAR_SPI_0_DEVICE_ID
#define SPI_SELECT              0x01

#define COMMAND_PAGE_PROGRAM    0x02 /* Page Program command */
#define COMMAND_QUAD_WRITE      0x32 /* Quad Input Fast Program */
#define COMMAND_RANDOM_READ     0x03 /* Random read command */
#define COMMAND_DUAL_READ       0x3B /* Dual Output Fast Read */
#define COMMAND_DUAL_IO_READ    0xBB /* Dual IO Fast Read */
#define COMMAND_QUAD_READ       0x6B /* Quad Output Fast Read */
#define COMMAND_QUAD_IO_READ    0xEB /* Quad IO Fast Read */
#define COMMAND_WRITE_ENABLE    0x06 /* Write Enable command */
#define COMMAND_SECTOR_ERASE    0xD8 /* Sector Erase command */
#define COMMAND_BULK_ERASE      0xC7 /* Bulk Erase command */
#define COMMAND_STATUSREG_READ  0x05 /* Status read command */

#define READ_WRITE_EXTRA_BYTES  4 /* Read/Write extra bytes */
#define WRITE_ENABLE_BYTES      1 /* Write Enable bytes */
#define SECTOR_ERASE_BYTES      4 /* Sector erase extra bytes */
#define BULK_ERASE_BYTES        1 /* Bulk erase extra bytes */
#define STATUS_READ_BYTES       2 /* Status read bytes count */
#define STATUS_WRITE_BYTES      2 /* Status write bytes count */

#define PAGE_SIZE               256

typedef enum {Blank, Counter, FSM} Config;
const u32 ConfigFlashAddr[] = {0xB00000, 0xC00000, 0xD00000};
const u32 DeltaFlashAddr    = 0xC00000 - 0xB00000;
const u32 PartitionByteSize = 0xA1728;

enum {BYTE1 = 0, BYTE2, BYTE3, BYTE4, BYTE5, BYTE6, BYTE7, BYTE8} Bytes;
//#define BYTE1               0 /* Byte 1 position */
//#define BYTE2               1 /* Byte 2 position */
//#define BYTE3               2 /* Byte 3 position */
//#define BYTE4               3 /* Byte 4 position */
//#define BYTE5               4 /* Byte 5 position */
//#define BYTE6               5 /* Byte 6 position */
//#define BYTE7               6 /* Byte 7 position */
//#define BYTE8               7 /* Byte 8 position */

#define DUAL_READ_DUMMY_BYTES       2
#define QUAD_READ_DUMMY_BYTES       4

#define DUAL_IO_READ_DUMMY_BYTES    2
#define QUAD_IO_READ_DUMMY_BYTES    5

int SpiFlashRead(XSpi*, u32, u32, u8);
int SpiFlashWriteEnable(XSpi*);
int ReadConfigToDDR3(XSpi*, u8*, u32, u8*);
int PrintConfigHeaderDDR3(Config);

static XSpi Spi;

static u8 ReadBuffer[PAGE_SIZE + READ_WRITE_EXTRA_BYTES + 4];
static u8 WriteBuffer[PAGE_SIZE + READ_WRITE_EXTRA_BYTES];

static u32 NumberOfConfigs = 0;

int main(void)
{
    int Status;
    XSpi_Config *ConfigPtr;

    ConfigPtr = XSpi_LookupConfig(SPI_DEVICE_ID);
    if (ConfigPtr == NULL) {
        return XST_DEVICE_NOT_FOUND;
    }

    Status = XSpi_CfgInitialize(&Spi, ConfigPtr, ConfigPtr->BaseAddress);
    if (Status != XST_SUCCESS) {
        return XST_FAILURE;
    }

    Status = XSpi_SetOptions(&Spi, XSP_MASTER_OPTION | XSP_MANUAL_SSELECT_OPTION);
    if(Status != XST_SUCCESS) {
        return XST_FAILURE;
    }

    Status = XSpi_SetSlaveSelect(&Spi, SPI_SELECT);
    if(Status != XST_SUCCESS) {
        return XST_FAILURE;
    }

    XSpi_Start(&Spi);
    XSpi_IntrGlobalDisable(&Spi);

    Status = SpiFlashWriteEnable(&Spi);
    if(Status != XST_SUCCESS) {
    return XST_FAILURE;
    }

    xil_printf("Carregando configuracoes...\n");
    Config i;
    u8* DDR3Addr;
    for(i = Blank; i <= FSM; i++) {
    	DDR3Addr = (u8*)(XPAR_DDR3_SDRAM_S_AXI_BASEADDR + (i+1)*DeltaFlashAddr);
    	ReadConfigToDDR3(&Spi, (u8*)ConfigFlashAddr[i], PartitionByteSize, DDR3Addr);
    	PrintConfigHeaderDDR3(i);
    }

    xil_printf("Fim!\r\n");

    return XST_SUCCESS;
}

int ReadConfigToDDR3(XSpi *SpiPtr, u8* FlashAddr, u32 ConfigByteNum, u8* DDR3Addr){
	u32 i,k;
	int Status;

	memset(ReadBuffer, 0x0, PAGE_SIZE + READ_WRITE_EXTRA_BYTES);

	xil_printf("Carregando %da configuracao da QSPI (@%x) para a DDR3 (@%x)... ", ++NumberOfConfigs,(u32)FlashAddr,(u32)DDR3Addr);
	for(i = 0; i < (ConfigByteNum/16) + 1; i++)
	{
		Status = SpiFlashRead(SpiPtr, (u32)(FlashAddr + 16*i), 16, COMMAND_RANDOM_READ);
		if(Status != XST_SUCCESS) {
			xil_printf("Erro!\n\r");
			return XST_FAILURE;
		}
		for(k=0; k<16; k++)
			*DDR3Addr++ = ReadBuffer[k+4];
	}
	xil_printf("Terminado!\n\r");

	return XST_SUCCESS;
}

int PrintConfigHeaderDDR3(Config Configuracao){
	u32 k;
	u8* DDR3Addr = (u8*)(XPAR_DDR3_SDRAM_S_AXI_BASEADDR + (Configuracao+1)*DeltaFlashAddr);

	xil_printf("Inicio do cabecalho da configuracao %d...\n\r",Configuracao);
	for(k = 0; k < 150; k++)
		xil_printf("0x%x\t", *DDR3Addr++);
	xil_printf("\r\nFim do cabecalho!\n\r");

	return XST_SUCCESS;
}

int SpiFlashRead(XSpi *SpiPtr, u32 Addr, u32 ByteCount, u8 ReadCmd)
{
    int Status;

    WriteBuffer[BYTE1] = ReadCmd;
    WriteBuffer[BYTE2] = (u8) (Addr >> 16);
    WriteBuffer[BYTE3] = (u8) (Addr >> 8);
    WriteBuffer[BYTE4] = (u8) Addr;

    Status = XSpi_Transfer( SpiPtr, WriteBuffer, ReadBuffer, (ByteCount + READ_WRITE_EXTRA_BYTES));
    if(Status != XST_SUCCESS) {
        return XST_FAILURE;
    }

    return XST_SUCCESS;
}

int SpiFlashWriteEnable(XSpi *SpiPtr)
{
    int Status;

    WriteBuffer[BYTE1] = COMMAND_WRITE_ENABLE;

    Status = XSpi_Transfer(SpiPtr, WriteBuffer, NULL, WRITE_ENABLE_BYTES);
    if(Status != XST_SUCCESS) {
        return XST_FAILURE;
    }

    return XST_SUCCESS;
}
