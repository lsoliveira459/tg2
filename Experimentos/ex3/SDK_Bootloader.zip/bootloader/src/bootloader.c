#include "xparameters.h"    /* EDK generated parameters */
#include "xspi.h"           /* SPI device driver */
#include "string.h"
#include "xil_printf.h"

#define SPI_DEVICE_ID           XPAR_SPI_0_DEVICE_ID
#define SPI_SELECT              0x01

#define CHECK(Status)			if ((Status) != XST_SUCCESS) return XST_FAILURE

#define COMMAND_PAGE_PROGRAM    0x02 /* Page Program command */
#define COMMAND_QUAD_WRITE      0x32 /* Quad Input Fast Program */
#define COMMAND_RANDOM_READ     0x03 /* Random read command */
#define COMMAND_DUAL_READ       0x3B /* Dual Output Fast Read */
#define COMMAND_DUAL_IO_READ    0xBB /* Dual IO Fast Read */
#define COMMAND_QUAD_READ       0x6B /* Quad Output Fast Read */
#define COMMAND_QUAD_IO_READ    0xEB /* Quad IO Fast Read */
#define COMMAND_WRITE_ENABLE    0x06 /* Write Enable command */
#define COMMAND_SECTOR_ERASE    0xD8 /* Sector Erase command */
#define COMMAND_BULK_ERASE      0xC7 /* Bulk Erase command */
#define COMMAND_STATUSREG_READ  0x05 /* Status read command */

#define READ_WRITE_EXTRA_BYTES  4 /* Read/Write extra bytes */
#define WRITE_ENABLE_BYTES      1 /* Write Enable bytes */
#define SECTOR_ERASE_BYTES      4 /* Sector erase extra bytes */
#define BULK_ERASE_BYTES        1 /* Bulk erase extra bytes */
#define STATUS_READ_BYTES       2 /* Status read bytes count */
#define STATUS_WRITE_BYTES      2 /* Status write bytes count */

#define PAGE_SIZE               256

#define DDR3_ADDR				XPAR_DDR3_SDRAM_S_AXI_BASEADDR
#define DDR3_OFFSET 			0x4000

#define HEADER_MAX_SIZE			200

typedef enum {Blank, Counter, FSM} Config;
static char* NomeConfigs[10]	 = {"Blank", "Counter", "FSM"};
static u8* ConfigFlashAddr[]     = {(u8*)0xB00000, (u8*)0xC00000, (u8*)0xD00000};
const  u32 DeltaFlashAddr        = 0xC00000 - 0xB00000;
static u32 TamanhoConfigBytes[3] = {0};

enum {BYTE1 = 0, BYTE2, BYTE3, BYTE4, BYTE5, BYTE6, BYTE7, BYTE8} Bytes;

#define DUAL_READ_DUMMY_BYTES       2
#define QUAD_READ_DUMMY_BYTES       4

#define DUAL_IO_READ_DUMMY_BYTES    2
#define QUAD_IO_READ_DUMMY_BYTES    5

int SpiFlashRead(XSpi*, u32, u32, u8);
int SpiFlashWriteEnable(XSpi*);

int ReadHeader(XSpi*, Config);
int LoadConfigToDDR3(XSpi*, Config, u8*);
int PrintConfigFromDDR3(Config, u32);

static XSpi Spi;

static u8 ReadBuffer[PAGE_SIZE + READ_WRITE_EXTRA_BYTES + 4];
static u8 WriteBuffer[PAGE_SIZE + READ_WRITE_EXTRA_BYTES];

int main(void) {
    XSpi_Config *ConfigPtr;
    // Procura um periferico SPI
    ConfigPtr = XSpi_LookupConfig(SPI_DEVICE_ID);
    if (ConfigPtr == NULL)	return XST_DEVICE_NOT_FOUND;
    // Inicializa este dispositivo
    CHECK(XSpi_CfgInitialize(&Spi, ConfigPtr, ConfigPtr->BaseAddress));
    // Configura o dispositivo como mestre e a selecao do servo como sendo manual
    // para impedir a perda automatica da informacao do servo.
    CHECK(XSpi_SetOptions(&Spi, XSP_MASTER_OPTION | XSP_MANUAL_SSELECT_OPTION));
    // Seleciona o servo. Basicamente a QSPI.
    CHECK(XSpi_SetSlaveSelect(&Spi, SPI_SELECT));

    // Inicia o driver
    XSpi_Start(&Spi);
    // Desativa interrupcoes, forcando as funcoes de IO a bloquearem
    XSpi_IntrGlobalDisable(&Spi);

    // Ativa a permissao de escrita nas registradores da memoria
    CHECK(SpiFlashWriteEnable(&Spi));

    // Comeca o bootloader
    xil_printf("Carregando configuracoes...\n\r");
    u8 i;
    u8* DDR3Addr;
    for(i = (u8)Blank; i <= (u8)FSM; i++) {
    	DDR3Addr = (u8*)DDR3_ADDR + DDR3_OFFSET + (i+1)*DeltaFlashAddr;
    	ReadHeader(&Spi, i);
    	LoadConfigToDDR3(&Spi, i, DDR3Addr);
    }

    xil_printf("Fim!\r\n");

    return XST_SUCCESS;
}

int ReadHeader(XSpi *SpiPtr, Config NConfig){
	u32 i;
	u32 Restante, Posicao, Tamanho;
	int Status;
	u8 *NowAddr, *EndAddr;
	enum {Inicial, Hex, Comando, TamanhoComando, TamanhoString, String, TamanhoConfig} state;
	u8* buffer = (u8*)(DDR3_ADDR + DDR3_OFFSET);

	memset(buffer, 0x0, PAGE_SIZE + READ_WRITE_EXTRA_BYTES);

	NowAddr		= ConfigFlashAddr[NConfig];
	EndAddr		= ConfigFlashAddr[NConfig] + HEADER_MAX_SIZE;
	Posicao		= 0;
	Restante	= 0;
	Tamanho 	= 2;
	xil_printf("Processando cabecalho de %s em QSPI@0%x\n\r", NomeConfigs[NConfig] ,(u32)NowAddr);
	for(state = Inicial; NowAddr < EndAddr;) {
		// Desloca o buffer para nao estourar, resetando os contadores
		Restante -= Posicao;
		memmove(buffer,&buffer[Posicao],Restante);
		Posicao = 0;

		// Carrega informa��o suficiente para conter o proximo campo
		for(; Restante < Tamanho; NowAddr += 16) {
			Status = SpiFlashRead(SpiPtr, (u32)(NowAddr), 16, COMMAND_RANDOM_READ);
			if(Status != XST_SUCCESS) {
				xil_printf("Erro!\n\r");
				return XST_FAILURE;
			}
			for(i = 0; i < 16; i++, Restante++) // Salvando no buffer
				buffer[Restante] = ReadBuffer[i+4];
		}

		//xil_printf("S: %02d, ", state);
		xil_printf("\t- ");
		switch(state) {
			case Inicial: case TamanhoComando: case TamanhoString:
				// Imprimindo informacoes do tamanho
				xil_printf("T: 02 byte(s), C: 0x");
				Tamanho = ((u32)(buffer[Posicao])) & 0x00ff;
				if(buffer[Posicao] < 16)
					xil_printf("0%x ",Tamanho);
				else
					xil_printf("%x ", Tamanho);
				Tamanho <<= 8;
				Tamanho |= ((u32)buffer[++Posicao]) & 0x00ff;
				if(buffer[Posicao++] < 16)
					xil_printf("0%x ",Tamanho & 0x00ff);
				else
					xil_printf("%x ", Tamanho & 0x00ff);
				xil_printf(" (%d byte(s))\n\r", Tamanho);

				if(state == Inicial)
					state = Hex;
				else if(state == TamanhoComando)
					state = Comando;
				else
					state = String;
				continue;
			case Hex: // Imprime frase em hex
				xil_printf("T: %02d byte(s), C: 0x", Tamanho);
				for(i = 0; i < Tamanho; i++, Posicao++){
					if(buffer[Posicao] < 16)
						xil_printf("0%x ", buffer[Posicao]);
					else
						xil_printf("%x ",  buffer[Posicao]);
				}
				xil_printf("\n\r");
				state = TamanhoComando;
				Tamanho = 2;
				continue;
			case Comando: // Imprime comando
				xil_printf("T: 01 byte(s), C: 0x%x ('%c')\n\r", buffer[Posicao], (char)buffer[Posicao]);
				if(buffer[Posicao++] == 'e') {
					state = TamanhoConfig;
					Tamanho = 4;
				} else {
					state = TamanhoString;
					Tamanho = 2;
				}
				continue;
			case String: // Estado que apenas imprime a string
				xil_printf("T: %02d byte(s), C: ", Tamanho);
				for(i=0; i < Tamanho; i++, Posicao++)
					xil_printf("%c",(char)buffer[Posicao]);
				xil_printf("\n\r");

				state = Comando;
				Tamanho = 1;
				continue;
			case TamanhoConfig: // Estado que captura o tamanho da configuracao
				xil_printf("T: 04 byte(s), C: ");
				for(i = 0; i < 4; i++, Posicao++) {// O tamanho tem 4 bytes ponto.
					Tamanho <<= 8;
					Tamanho |= ((u32)buffer[Posicao] & 0x00ff);
					if(buffer[Posicao] < 16)
						xil_printf("0%x ", buffer[Posicao]);
					else
						xil_printf("%x ",  buffer[Posicao]);
				}
				xil_printf("(%d bytes)\n\r", Tamanho);
				xil_printf("Tamanho do cabecalho: %d bytes\n\r",NowAddr - ConfigFlashAddr[NConfig] - Restante + Posicao);
				TamanhoConfigBytes[NConfig] = Tamanho + NowAddr - ConfigFlashAddr[NConfig] - Restante + Posicao;
				return XST_SUCCESS;
			default:
				xil_printf("Erro!\n\r");
				return XST_FAILURE;
		}
	}

	return XST_SUCCESS;
}

int LoadConfigToDDR3(XSpi *SpiPtr, Config NConfig, u8* DDR3Addr) {
	u32 i,k;
	int Status;
	u8* DDR3AddrPtr = DDR3Addr;
	u8* FlashAddr = ConfigFlashAddr[NConfig];

	memset(ReadBuffer, 0x0, PAGE_SIZE + READ_WRITE_EXTRA_BYTES);

	xil_printf("Carregando a configuracao %s (QSPI@%x -> DDR3@%x)... ", NomeConfigs[NConfig], (u32)FlashAddr, (u32)DDR3AddrPtr);
	for(i = 0; i < (TamanhoConfigBytes[NConfig]/16) + 1; i++) {
		Status = SpiFlashRead(SpiPtr, (u32)(FlashAddr + 16*i), 16, COMMAND_RANDOM_READ);
		if(Status != XST_SUCCESS) {
			xil_printf("Erro!\n\r");
			return XST_FAILURE;
		}
		for(k=0; k<16; k++)
			*DDR3AddrPtr++ = ReadBuffer[k+4];
	}

	xil_printf("Terminado!\n\r");

	return XST_SUCCESS;
}

int PrintConfigFromDDR3(Config NConfig, u32 QuantosBytes){
	u32 k;
	u8* DDR3Addr = (u8*)(XPAR_DDR3_SDRAM_S_AXI_BASEADDR + (NConfig+1)*DeltaFlashAddr);

	xil_printf("Imprimindo %d byte(s) da configuracao %d...\n\r", QuantosBytes, NConfig);
	for(k = 0; k < QuantosBytes; k++, DDR3Addr++)
		if(*DDR3Addr < 16)
			xil_printf("0x0%x ", *DDR3Addr);
		else
			xil_printf("0x%x ", *DDR3Addr);
	xil_printf("\r\nTerminado!\n\r");

	return XST_SUCCESS;
}

int SpiFlashRead(XSpi *SpiPtr, u32 Addr, u32 ByteCount, u8 ReadCmd)
{
    int Status;

    WriteBuffer[BYTE1] = ReadCmd;
    WriteBuffer[BYTE2] = (u8) (Addr >> 16);
    WriteBuffer[BYTE3] = (u8) (Addr >> 8);
    WriteBuffer[BYTE4] = (u8) Addr;

    Status = XSpi_Transfer( SpiPtr, WriteBuffer, ReadBuffer, (ByteCount + READ_WRITE_EXTRA_BYTES));
    if(Status != XST_SUCCESS) {
        return XST_FAILURE;
    }

    return XST_SUCCESS;
}

int SpiFlashWriteEnable(XSpi *SpiPtr)
{
    int Status;

    WriteBuffer[BYTE1] = COMMAND_WRITE_ENABLE;

    Status = XSpi_Transfer(SpiPtr, WriteBuffer, NULL, WRITE_ENABLE_BYTES);
    if(Status != XST_SUCCESS) {
        return XST_FAILURE;
    }

    return XST_SUCCESS;
}
