1 - To generate the asmips assemblee, run make
2 - The files Syntaxe and psd_instr.sx must be in the same repository than your assemblee code
