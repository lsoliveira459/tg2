#ifndef M_SYNTHETISEUR_FLAG
#define M_SYNTHETISEUR_FLAG

#include <stdio.h>

int synthese();
void write_objet(FILE * f_obj);
void write_liste(FILE * f_lst, FILE * f_src);

#endif
